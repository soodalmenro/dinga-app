/* -*- c-basic-offset: 4 indent-tabs-mode: nil -*-  vi:set ts=8 sts=4 sw=4: */

/*
  NNLS-Chroma / Chordino

  Audio feature extraction plugins for chromagram and chord
  estimation.

  Centre for Digital Music, Queen Mary University of London.
  This file copyright 2008-2010 Matthias Mauch and QMUL.

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License as
  published by the Free Software Foundation; either version 2 of the
  License, or (at your option) any later version.  See the file
  COPYING included with this distribution for more information.
*/

#ifndef _CHROMA_METHODS_H_
#define _CHROMA_METHODS_H_

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

enum {
    nBPS = 3, // bins per semitone
    nOctave = 7,
    nNote = nOctave * 12 * nBPS + 2 * (nBPS/2+1), // a core over all octaves, plus some overlap at top and bottom
    MIDI_basenote = 45
};

// Special convolution of the nNote values of convolvee by the lenKernel ones
// of kernel (odd), into out[nNote]: see chromamethods.c
void special_convolution(const float *convolvee, const float *kernel, int lenKernel, float *out);
// The note dictionary: nNote bins for each of 84 semitones, whose harmonics
// fade by s_param each
void dictionary_matrix(float *dm, float s_param);
// The matrix (nNote rows of blocksize / 2) mapping a magnitude spectrum to the
// log-frequency spectrum
void log_freq_matrix(int fs, int blocksize, float *outmatrix);

// The chords Chordino tells apart: twelve of each type, then N
typedef struct {
    int size;
    // size * 24: bass pitch classes (0-11) then treble ones (12-23), A-based,
    // each template scaled to unit norm (N to less, by boostN)
    float *templates;
    char **names;           // "C", "Am/C", ..., "N"
    // The MIDI notes of chord i are notes[noteStart[i]] up to notes[noteStart[i + 1]]
    int *noteStart;
    int *notes;
    // For each chord, a bit for each root (0 = A) of the chords on other roots
    // with the same notes: Fsus2 and Csus4, Am7 and C6, F#º and Am6, and the
    // augmented triads a major third apart
    int *sameNotesRoots;
} chord_dictionary_t;

// harteSyntax names chords as C:min and C/b3 rather than Cm and Cm/Eb
chord_dictionary_t *chord_dictionary_create(float boostN, bool harteSyntax);
void chord_dictionary_destroy(chord_dictionary_t *dictionary);

static const float basswindow[] = {0.001769, 0.015848, 0.043608, 0.084265, 0.136670, 0.199341, 0.270509, 0.348162, 0.430105, 0.514023, 0.597545, 0.678311, 0.754038, 0.822586, 0.882019, 0.930656, 0.967124, 0.990393, 0.999803, 0.995091, 0.976388, 0.944223, 0.899505, 0.843498, 0.777785, 0.704222, 0.624888, 0.542025, 0.457975, 0.375112, 0.295778, 0.222215, 0.156502, 0.100495, 0.055777, 0.023612, 0.004909, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000};
static const float treblewindow[] = {0.000350, 0.003144, 0.008717, 0.017037, 0.028058, 0.041719, 0.057942, 0.076638, 0.097701, 0.121014, 0.146447, 0.173856, 0.203090, 0.233984, 0.266366, 0.300054, 0.334860, 0.370590, 0.407044, 0.444018, 0.481304, 0.518696, 0.555982, 0.592956, 0.629410, 0.665140, 0.699946, 0.733634, 0.766016, 0.796910, 0.826144, 0.853553, 0.878986, 0.902299, 0.923362, 0.942058, 0.958281, 0.971942, 0.982963, 0.991283, 0.996856, 0.999650, 0.999650, 0.996856, 0.991283, 0.982963, 0.971942, 0.958281, 0.942058, 0.923362, 0.902299, 0.878986, 0.853553, 0.826144, 0.796910, 0.766016, 0.733634, 0.699946, 0.665140, 0.629410, 0.592956, 0.555982, 0.518696, 0.481304, 0.444018, 0.407044, 0.370590, 0.334860, 0.300054, 0.266366, 0.233984, 0.203090, 0.173856, 0.146447, 0.121014, 0.097701, 0.076638, 0.057942, 0.041719, 0.028058, 0.017037, 0.008717, 0.003144, 0.000350};

#ifdef __cplusplus
}
#endif

#include "nnls.h"

#endif
