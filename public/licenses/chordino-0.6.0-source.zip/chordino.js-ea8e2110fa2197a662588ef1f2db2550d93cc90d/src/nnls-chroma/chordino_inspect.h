/* -*- c-basic-offset: 4 indent-tabs-mode: nil -*-  vi:set ts=8 sts=4 sw=4: */

/*
  Inspection hooks for internal visualization (examples/player and
  examples/realtime).

  Only compiled when CHORDINO_INSPECT is defined, which the separate
  chordino-inspect.js build does (see BUILD.md). Without it chordino.c
  compiles to exactly what ships in chordino.js. The hooks are free functions so
  src/chordino.h keeps its API; src/inspect.c implements them.
*/

#ifndef CHORDINO_INSPECT_H
#define CHORDINO_INSPECT_H

#ifdef CHORDINO_INSPECT

#ifdef __cplusplus
extern "C" {
#endif

// Called once per chordino_decode(), before the first frame, with the names of
// the nChord chords.
void chordino_inspect_begin(int nChord, char *const *chordNames);

// Called for every frame, in order, with its time in seconds.
//  chroma:         24 bins, bass (0-11) stacked under treble (12-23), A-based
//  smoothedChroma: the 24 bins the chord matcher actually scores
//  salience:       one value per chord, after the confidence gate
//                  (what the Viterbi decoder receives)
//  semitones:      84 semitone activations, A0 upwards
//  gate:           confidence gate outcome: 0 passed, 1 the best chord did not
//                  beat N by enough, 2 a chord on another root came too close
void chordino_inspect_frame(double seconds,
                            const float *chroma,
                            const double *smoothedChroma,
                            const double *salience,
                            const float *semitones,
                            int gate);

#ifdef __cplusplus
}
#endif

#endif

#endif
